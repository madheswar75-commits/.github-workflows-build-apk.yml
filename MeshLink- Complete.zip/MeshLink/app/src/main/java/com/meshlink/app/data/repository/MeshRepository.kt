package com.meshlink.app.data.repository

import com.meshlink.app.data.MeshStatus
import com.meshlink.app.data.MessagePriority
import com.meshlink.app.data.PeerDeviceUi
import com.meshlink.app.data.local.entity.ConversationEntity
import com.meshlink.app.data.local.entity.EmergencyMessageEntity
import com.meshlink.app.data.local.entity.MessageEntity
import com.meshlink.app.data.local.entity.UserEntity
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.StateFlow

/**
 * The one gateway the ViewModel layer talks to. Phase 2 made this a thin
 * wrapper over Room. Phase 3 adds a MeshTransportManager (real Nearby
 * Connections/Bluetooth/Wi-Fi) alongside it — sendMessage()/
 * sendEmergencyMessage() now attempt a real transfer when a peer is
 * connected, and connect/discover/send are all backed by real radios.
 * The ViewModel-facing shape barely changed for this, which was the point
 * of keeping this layer separate from both Room and the transport code.
 */
interface MeshRepository {

    fun observeCurrentUser(): Flow<UserEntity?>
    suspend fun ensureLocalUser(defaultDisplayName: String, defaultDeviceName: String): UserEntity

    fun observeConversations(): Flow<List<ConversationEntity>>
    suspend fun createManualConversation(peerDisplayName: String): ConversationEntity

    fun observeMessages(conversationId: String): Flow<List<MessageEntity>>

    /**
     * Always persists first (offline-first): the message is written to
     * Room as QUEUED before anything else happens. If the target peer is
     * currently connected, a real send is attempted immediately; if not,
     * it stays QUEUED and is automatically retried the moment that peer
     * connects (see MeshRepositoryImpl's Connected event handling).
     */
    suspend fun sendMessage(
        conversationId: String,
        content: String,
        priority: MessagePriority = MessagePriority.NORMAL
    ): MessageEntity

    fun observePendingMessageCount(): Flow<Int>
    fun observeConnectedPeerCount(): Flow<Int>

    fun observeEmergencyHistory(): Flow<List<EmergencyMessageEntity>>

    /** Persists as QUEUED, then broadcasts to every currently connected peer. */
    suspend fun sendEmergencyMessage(content: String): EmergencyMessageEntity

    // -------- Phase 3: real mesh transport --------

    /** Real, aggregate status — never fabricated. See MeshStatus for what each value means. */
    fun observeMeshStatus(): StateFlow<MeshStatus>

    /** Real devices discovered/connected via Nearby Connections. Excludes manually-created (Phase 2) peers. */
    fun observeDiscoveredPeers(): Flow<List<PeerDeviceUi>>

    /** Starts real BLE discovery + advertising. Caller must have already obtained runtime permissions. */
    fun startDiscovery()
    fun stopDiscovery()

    fun connectToPeer(peerId: String)
    fun disconnectFromPeer(peerId: String)
}
