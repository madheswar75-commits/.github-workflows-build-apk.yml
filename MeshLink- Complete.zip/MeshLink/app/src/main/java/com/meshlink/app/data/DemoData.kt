package com.meshlink.app.data

/**
 * DEMO DATA — NOT A REAL CONNECTION.
 *
 * Phase 1 has no Bluetooth/Wi-Fi layer yet (that's Phase 3+), and no Room
 * database yet (Phase 2), so screens have nothing real to render. Rather
 * than fake a "Connected" state, every value here is routed through the
 * UI with an explicit "Demo" badge (see Nearby/Mesh screens) so it is
 * never confused with a live peer. This object is deleted/replaced
 * field-by-field as each phase lands:
 *   Phase 2 -> conversations/messages come from Room instead
 *   Phase 3 -> peers come from real BLE/Nearby scan results instead
 */
object DemoData {

    val demoPeers = listOf(
        PeerDeviceUi("demo-1", "Arun's Phone", PeerConnectionState.CONNECTED, hopsAway = 1, isDemo = true),
        PeerDeviceUi("demo-2", "Karthik's Phone", PeerConnectionState.AVAILABLE, hopsAway = 1, isDemo = true),
        PeerDeviceUi("demo-3", "Rahul's Phone", PeerConnectionState.CONNECTING, hopsAway = 2, isDemo = true)
    )

    val demoConversations = listOf(
        ConversationUi("c1", "Arun's Phone", "Hello 👋", "10:32 AM", unreadCount = 0),
        ConversationUi("c2", "Karthik's Phone", "On my way to Block A", "09:58 AM", unreadCount = 2)
    )

    val demoMessages = listOf(
        MessageUi("m1", "Hey, are you near the library?", "10:30 AM", MessageStatus.DELIVERED, isOutgoing = true),
        MessageUi("m2", "Hello 👋", "10:32 AM", MessageStatus.SENT, isOutgoing = false)
    )
}
