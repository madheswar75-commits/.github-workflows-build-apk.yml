package com.meshlink.app.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.meshlink.app.data.MessageStatus
import com.meshlink.app.ui.theme.MeshGreenSignal
import com.meshlink.app.ui.theme.MeshRedEmergency
import com.meshlink.app.viewmodel.EmergencyViewModel
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

private enum class SendState { IDLE, CONFIRMING, ATTEMPTING, SENT, NO_ROUTE }

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun EmergencyScreen(viewModel: EmergencyViewModel) {
    var state by remember { mutableStateOf(SendState.IDLE) }
    var message by remember { mutableStateOf("EMERGENCY: Assistance required near Block A.") }
    val history by viewModel.history.collectAsState()

    Scaffold(
        topBar = { TopAppBar(title = { Text("Emergency") }) }
    ) { padding ->
        LazyColumn(
            modifier = Modifier
                .padding(padding)
                .fillMaxSize()
                .padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            item {
                OutlinedTextField(
                    value = message,
                    onValueChange = { message = it },
                    label = { Text("Emergency message") },
                    modifier = Modifier.fillMaxWidth(),
                    minLines = 2
                )

                Spacer(Modifier.height(32.dp))

                Button(
                    onClick = { state = SendState.CONFIRMING },
                    colors = ButtonDefaults.buttonColors(containerColor = MeshRedEmergency),
                    shape = CircleShape,
                    modifier = Modifier.size(180.dp)
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Icon(Icons.Filled.Warning, contentDescription = null, modifier = Modifier.size(36.dp))
                        Spacer(Modifier.height(6.dp))
                        Text("SEND\nEMERGENCY\nALERT", textAlign = TextAlign.Center)
                    }
                }

                Spacer(Modifier.height(24.dp))

                when (state) {
                    SendState.ATTEMPTING -> {
                        CircularProgressIndicator()
                        Spacer(Modifier.height(8.dp))
                        Text("Attempting delivery via available MeshLink connections\u2026")
                    }
                    SendState.SENT -> {
                        StatusChip("SENT TO CONNECTED PEERS", MeshGreenSignal)
                        Spacer(Modifier.height(8.dp))
                        Text(
                            "Broadcast to every currently connected MeshLink device over " +
                                "Bluetooth/Wi-Fi - a real transfer, no internet involved. Each " +
                                "recipient's own device sends back a delivery receipt; check the " +
                                "message's status once it arrives.",
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.outline,
                            textAlign = TextAlign.Center
                        )
                    }
                    SendState.NO_ROUTE -> {
                        StatusChip("NO ROUTE \u2014 QUEUED LOCALLY", MeshRedEmergency)
                        Spacer(Modifier.height(8.dp))
                        Text(
                            "No peers are connected right now. Go to the Nearby tab, scan, and " +
                                "connect to at least one real device, then try again. The alert " +
                                "was saved to the local database as HIGH PRIORITY / QUEUED - a " +
                                "real write, honestly reported as undelivered rather than shown " +
                                "as sent.",
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.outline,
                            textAlign = TextAlign.Center
                        )
                    }
                    else -> {}
                }

                Spacer(Modifier.height(32.dp))
                Text(
                    "Alert History",
                    style = MaterialTheme.typography.titleMedium,
                    modifier = Modifier.fillMaxWidth()
                )
                Spacer(Modifier.height(8.dp))
            }

            if (history.isEmpty()) {
                item {
                    EmptyState("No emergency alerts sent yet. Sent alerts persist here across restarts.")
                }
            } else {
                items(history, key = { it.emergencyId }) { entry ->
                    EmergencyHistoryRow(
                        content = entry.content,
                        status = MessageStatus.valueOf(entry.status),
                        timestamp = entry.createdAt
                    )
                }
            }
        }
    }

    if (state == SendState.CONFIRMING) {
        AlertDialog(
            onDismissRequest = { state = SendState.IDLE },
            title = { Text("Send emergency alert?") },
            text = {
                Text(
                    "This will be marked HIGH PRIORITY and saved locally, then sent to every " +
                        "connected MeshLink peer and relayed onward where possible. " +
                        "Message: \"$message\""
                )
            },
            confirmButton = {
                TextButton(onClick = {
                    state = SendState.ATTEMPTING
                    viewModel.sendEmergency(
                        content = message,
                        onSent = { state = SendState.SENT },
                        onNoRoute = { state = SendState.NO_ROUTE }
                    )
                }) { Text("Send", color = MeshRedEmergency) }
            },
            dismissButton = {
                TextButton(onClick = { state = SendState.IDLE }) { Text("Cancel") }
            }
        )
    }
}

private val historyTimeFormat = SimpleDateFormat("MMM d, h:mm a", Locale.getDefault())

@Composable
private fun EmergencyHistoryRow(content: String, status: MessageStatus, timestamp: Long) {
    ElevatedCard(modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp)) {
        Column(Modifier.padding(12.dp)) {
            Text(content, style = MaterialTheme.typography.bodyMedium)
            Spacer(Modifier.height(6.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                StatusChip(status.name, colorForMessageStatus(status))
                Text(
                    historyTimeFormat.format(Date(timestamp)),
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.outline
                )
            }
        }
    }
}
