package com.meshlink.app.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Person
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.unit.dp
import com.meshlink.app.data.ConversationUi
import com.meshlink.app.data.MeshStatus
import com.meshlink.app.viewmodel.HomeViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HomeScreen(
    viewModel: HomeViewModel,
    onOpenConversation: (String) -> Unit
) {
    val conversations by viewModel.conversations.collectAsState()
    val pendingMessages by viewModel.pendingMessageCount.collectAsState()
    val nearbyPeerCount by viewModel.connectedPeerCount.collectAsState()
    val meshStatus by viewModel.meshStatus.collectAsState()
    var showNewConversationDialog by remember { mutableStateOf(false) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("MeshLink") },
                actions = {
                    Box(
                        modifier = Modifier
                            .padding(end = 12.dp)
                            .size(36.dp)
                            .clip(CircleShape)
                            .background(MaterialTheme.colorScheme.primaryContainer),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(Icons.Filled.Person, contentDescription = "Profile")
                    }
                }
            )
        },
        floatingActionButton = {
            FloatingActionButton(onClick = { showNewConversationDialog = true }) {
                Icon(Icons.Filled.Add, contentDescription = "New conversation")
            }
        }
    ) { padding ->
        LazyColumn(
            modifier = Modifier
                .padding(padding)
                .fillMaxSize(),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            item { MeshStatusCard(meshStatus, nearbyPeerCount, pendingMessages) }

            item {
                Text("Recent Conversations", style = MaterialTheme.typography.titleMedium)
            }

            if (conversations.isEmpty()) {
                item {
                    EmptyState(
                        "No conversations yet. Connect to a real nearby MeshLink device from " +
                            "the Nearby tab, or tap + to name a peer manually for testing. " +
                            "Messages you send are saved for real and will still be here after " +
                            "you restart the app."
                    )
                }
            } else {
                items(conversations, key = { it.id }) { convo ->
                    ConversationRow(convo, onClick = { onOpenConversation(convo.id) })
                }
            }
        }
    }

    if (showNewConversationDialog) {
        NewConversationDialog(
            onDismiss = { showNewConversationDialog = false },
            onCreate = { name ->
                showNewConversationDialog = false
                viewModel.createConversation(name, onCreated = onOpenConversation)
            }
        )
    }
}

@Composable
private fun NewConversationDialog(onDismiss: () -> Unit, onCreate: (String) -> Unit) {
    var name by remember { mutableStateOf("") }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("New conversation") },
        text = {
            Column {
                Text(
                    "For a real conversation, connect to a nearby device from the Nearby tab " +
                        "instead. This creates a manual (unconnected) test peer — useful for " +
                        "trying the chat UI without a second phone nearby.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.outline
                )
                Spacer(Modifier.height(12.dp))
                OutlinedTextField(
                    value = name,
                    onValueChange = { name = it },
                    label = { Text("Peer name") },
                    singleLine = true
                )
            }
        },
        confirmButton = {
            TextButton(onClick = { onCreate(name) }, enabled = name.isNotBlank()) { Text("Create") }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Cancel") }
        }
    )
}

@Composable
private fun MeshStatusCard(status: MeshStatus, peerCount: Int, pending: Int) {
    ElevatedCard(modifier = Modifier.fillMaxWidth()) {
        Column(Modifier.padding(16.dp)) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween,
                modifier = Modifier.fillMaxWidth()
            ) {
                Text("Mesh Status", style = MaterialTheme.typography.titleMedium)
                StatusChip(labelForMeshStatus(status), colorForMeshStatus(status))
            }
            Spacer(Modifier.height(12.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(24.dp)) {
                StatLabel("Nearby Peers", peerCount.toString())
                StatLabel("Pending Messages", pending.toString())
            }
            Spacer(Modifier.height(8.dp))
            Text(
                "Nearby Peers and Mesh Status reflect the real Bluetooth/Wi-Fi transport layer " +
                    "(scan from the Nearby tab). Pending Messages is a real count of QUEUED rows.",
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.outline
            )
        }
    }
}

@Composable
private fun StatLabel(label: String, value: String) {
    Column {
        Text(value, style = MaterialTheme.typography.titleLarge)
        Text(label, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.outline)
    }
}

@Composable
private fun ConversationRow(convo: ConversationUi, onClick: () -> Unit) {
    ListItem(
        headlineContent = { Text(convo.peerName) },
        supportingContent = {
            Text(convo.lastMessage.ifBlank { "No messages yet" }, maxLines = 1)
        },
        trailingContent = {
            Column(horizontalAlignment = Alignment.End) {
                Text(convo.lastTimestamp, style = MaterialTheme.typography.labelSmall)
                if (convo.unreadCount > 0) {
                    Spacer(Modifier.height(4.dp))
                    Badge { Text(convo.unreadCount.toString()) }
                }
            }
        },
        modifier = Modifier
            .clip(MaterialTheme.shapes.medium)
            .clickable(onClick = onClick)
    )
}

@Composable
fun EmptyState(message: String) {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 32.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(message, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.outline)
    }
}
