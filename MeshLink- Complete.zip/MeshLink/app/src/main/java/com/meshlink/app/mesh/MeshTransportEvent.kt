package com.meshlink.app.mesh

/**
 * Everything MeshTransportManager can report, keyed by our stable `peerId`
 * (never Nearby's ephemeral endpointId — that mapping is resolved and
 * hidden inside MeshTransportManager itself).
 */
sealed class MeshTransportEvent {
    /** Real: a nearby MeshLink advertiser was heard over BLE. Not yet connected. */
    data class PeerFound(val peerId: String, val displayName: String) : MeshTransportEvent()

    /** Real: we stopped hearing that peer's advertisement. */
    data class PeerLost(val peerId: String) : MeshTransportEvent()

    /** Real: a connection handshake with this peer is in progress. */
    data class Connecting(val peerId: String) : MeshTransportEvent()

    /** Real: a live Bluetooth/Wi-Fi link to this peer now exists. */
    data class Connected(val peerId: String) : MeshTransportEvent()

    data class ConnectionFailed(val peerId: String, val reason: String?) : MeshTransportEvent()

    /** Real: the link to this peer dropped (they moved away, closed the app, etc). */
    data class Disconnected(val peerId: String) : MeshTransportEvent()

    /** Real: bytes arrived and parsed as a MeshEnvelope (a chat message or an ack). */
    data class MessageReceived(val fromPeerId: String, val envelope: MeshEnvelope) : MeshTransportEvent()

    /** Real: Nearby confirmed the payload's bytes fully reached the peer's radio stack. */
    data class MessageSendSucceeded(val messageId: String) : MeshTransportEvent()

    /** Real: the payload transfer failed or was canceled mid-flight. */
    data class MessageSendFailed(val messageId: String) : MeshTransportEvent()

    data class TransportError(val message: String) : MeshTransportEvent()
}
