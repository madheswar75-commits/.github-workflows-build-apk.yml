package com.meshlink.app.data.local.entity

import androidx.room.Entity
import androidx.room.PrimaryKey

/**
 * One conversation thread with a single peer.
 *
 * `lastMessagePreview`/`lastMessageTimestamp` are denormalized copies of
 * the latest [MessageEntity] for that conversation, updated by
 * MeshRepository on every send/receive, purely so the Home screen can
 * render the conversation list with a single query instead of a join.
 */
@Entity(tableName = "conversations")
data class ConversationEntity(
    @PrimaryKey val conversationId: String,
    val peerId: String,
    val peerDisplayName: String,
    val lastMessagePreview: String,
    val lastMessageTimestamp: Long,
    val unreadCount: Int = 0
)
