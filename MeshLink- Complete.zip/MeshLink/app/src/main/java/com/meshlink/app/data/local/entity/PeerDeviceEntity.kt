package com.meshlink.app.data.local.entity

import androidx.room.Entity
import androidx.room.PrimaryKey

/**
 * A known peer device.
 *
 * `source` distinguishes how this row came to exist, and matters a lot for
 * honesty about what's real:
 *   - "MANUAL"     Phase 2: the user typed a peer name to create a test
 *                  conversation. `connectionState` for these is always
 *                  DISCONNECTED — no real link exists, this just lets
 *                  Chat/Home be tested against the real database before
 *                  any transport layer exists.
 *   - "DISCOVERED" Phase 3+: a real BLE/Wi-Fi scan result. Only rows with
 *                  this source may ever legitimately reach connectionState
 *                  = CONNECTED.
 *
 * This table is intentionally separate from Nearby screen's current
 * DEMO_DATA (com.meshlink.app.data.DemoData) — that object is UI-only
 * sample content and never touches Room.
 */
@Entity(tableName = "peer_devices")
data class PeerDeviceEntity(
    @PrimaryKey val peerId: String,
    val displayName: String,
    val connectionState: String, // PeerConnectionState.name
    val source: String,          // "MANUAL" | "DISCOVERED"
    val lastSeenTimestamp: Long,
    val hopsAway: Int = 1
)
