package com.meshlink.app.data.local

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import com.meshlink.app.data.local.dao.ConversationDao
import com.meshlink.app.data.local.dao.EmergencyMessageDao
import com.meshlink.app.data.local.dao.MessageDao
import com.meshlink.app.data.local.dao.PeerDeviceDao
import com.meshlink.app.data.local.dao.UserDao
import com.meshlink.app.data.local.entity.ConversationEntity
import com.meshlink.app.data.local.entity.EmergencyMessageEntity
import com.meshlink.app.data.local.entity.MessageEntity
import com.meshlink.app.data.local.entity.PeerDeviceEntity
import com.meshlink.app.data.local.entity.UserEntity

/**
 * The single local database backing all offline-first functionality.
 * No network, no cloud sync — this is the entire persistence layer, exactly
 * as required by spec section 7 (offline-first) and section 2 (no cloud
 * messaging service as the core mechanism).
 *
 * exportSchema is left false for now to keep Phase 2 simple; turn it on
 * (with a checked-in schema folder) before shipping, so future entity
 * changes get real migrations instead of destructive fallback.
 */
@Database(
    entities = [
        UserEntity::class,
        MessageEntity::class,
        ConversationEntity::class,
        PeerDeviceEntity::class,
        EmergencyMessageEntity::class
    ],
    version = 1,
    exportSchema = false
)
abstract class MeshLinkDatabase : RoomDatabase() {

    abstract fun userDao(): UserDao
    abstract fun messageDao(): MessageDao
    abstract fun conversationDao(): ConversationDao
    abstract fun peerDeviceDao(): PeerDeviceDao
    abstract fun emergencyMessageDao(): EmergencyMessageDao

    companion object {
        @Volatile private var INSTANCE: MeshLinkDatabase? = null

        fun getInstance(context: Context): MeshLinkDatabase =
            INSTANCE ?: synchronized(this) {
                INSTANCE ?: Room.databaseBuilder(
                    context.applicationContext,
                    MeshLinkDatabase::class.java,
                    "meshlink.db"
                ).build().also { INSTANCE = it }
            }
    }
}
