package com.meshlink.app.data.local.dao

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import com.meshlink.app.data.local.entity.PeerDeviceEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface PeerDeviceDao {
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(peer: PeerDeviceEntity)

    @Query("SELECT * FROM peer_devices ORDER BY lastSeenTimestamp DESC")
    fun observeAll(): Flow<List<PeerDeviceEntity>>

    @Query("SELECT * FROM peer_devices WHERE peerId = :peerId")
    suspend fun getById(peerId: String): PeerDeviceEntity?

    // Real connections only ever come from source = 'DISCOVERED'. This was
    // always honestly 0 in Phase 2 (nothing populated it); from Phase 3 it
    // reflects real Nearby Connections links.
    @Query("SELECT COUNT(*) FROM peer_devices WHERE connectionState = 'CONNECTED' AND source = 'DISCOVERED'")
    fun observeConnectedCount(): Flow<Int>

    @Query("SELECT peerId FROM peer_devices WHERE connectionState = 'CONNECTED' AND source = 'DISCOVERED'")
    suspend fun getConnectedPeerIds(): List<String>
}
