package com.meshlink.app.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.meshlink.app.data.ConversationUi
import com.meshlink.app.data.MeshStatus
import com.meshlink.app.data.repository.MeshRepository
import com.meshlink.app.data.toUi
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class HomeViewModel(private val repository: MeshRepository) : ViewModel() {

    val conversations: StateFlow<List<ConversationUi>> = repository.observeConversations()
        .map { list -> list.map { it.toUi() } }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val pendingMessageCount: StateFlow<Int> = repository.observePendingMessageCount()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0)

    val connectedPeerCount: StateFlow<Int> = repository.observeConnectedPeerCount()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0)

    // Real aggregate status from the transport layer (Phase 3): OFFLINE
    // until discovery/advertising starts, SCANNING while active with no
    // peer connected yet, CONNECTED once at least one real peer link is up.
    val meshStatus: StateFlow<MeshStatus> = repository.observeMeshStatus()

    init {
        viewModelScope.launch { repository.ensureLocalUser("You", "This Device") }
    }

    fun createConversation(peerName: String, onCreated: (conversationId: String) -> Unit) {
        if (peerName.isBlank()) return
        viewModelScope.launch {
            val conversation = repository.createManualConversation(peerName.trim())
            onCreated(conversation.conversationId)
        }
    }

    class Factory(private val repository: MeshRepository) : ViewModelProvider.Factory {
        @Suppress("UNCHECKED_CAST")
        override fun <T : ViewModel> create(modelClass: Class<T>): T = HomeViewModel(repository) as T
    }
}
