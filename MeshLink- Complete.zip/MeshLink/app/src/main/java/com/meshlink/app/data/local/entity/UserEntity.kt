package com.meshlink.app.data.local.entity

import androidx.room.Entity
import androidx.room.PrimaryKey

/**
 * Represents THIS device's local identity.
 *
 * Phase 2: a single row, generated on first launch, used as `senderId` on
 * outgoing messages. Phase 7 (Security) is where this gains a real
 * public/private keypair for message authentication — right now `userId`
 * is just a random UUID with no cryptographic guarantee attached to it.
 */
@Entity(tableName = "users")
data class UserEntity(
    @PrimaryKey val userId: String,
    val displayName: String,
    val deviceName: String,
    val createdAt: Long
)
