package com.meshlink.app.data

import android.content.Context
import com.meshlink.app.data.local.MeshLinkDatabase
import com.meshlink.app.data.repository.MeshRepository
import com.meshlink.app.data.repository.MeshRepositoryImpl

/**
 * Minimal manual dependency provider. No Hilt/Koin is introduced yet —
 * for a project this size a hand-written singleton holder is simpler to
 * follow and just as testable (MeshRepository is an interface, so a fake
 * can be swapped in for tests without touching this object at all).
 */
object ServiceLocator {
    @Volatile private var repository: MeshRepository? = null

    fun provideRepository(context: Context): MeshRepository =
        repository ?: synchronized(this) {
            repository ?: MeshRepositoryImpl(
                context.applicationContext,
                MeshLinkDatabase.getInstance(context)
            ).also { repository = it }
        }
}
