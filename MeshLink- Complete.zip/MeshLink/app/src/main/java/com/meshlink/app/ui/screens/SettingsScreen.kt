package com.meshlink.app.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier

private data class SettingsRow(val title: String, val subtitle: String, val toggle: Boolean = false)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsScreen() {
    var darkMode by remember { mutableStateOf(false) }
    var demoMode by remember { mutableStateOf(true) }

    Scaffold(
        topBar = { TopAppBar(title = { Text("Settings") }) }
    ) { padding ->
        LazyColumn(modifier = Modifier.padding(padding).fillMaxSize()) {
            item { SectionHeader("Profile") }
            item { ListItem(headlineContent = { Text("User name") }, supportingContent = { Text("Not set") }) }
            item { ListItem(headlineContent = { Text("Device name") }, supportingContent = { Text("This device's MeshLink ID") }) }

            item { SectionHeader("Appearance") }
            item {
                ListItem(
                    headlineContent = { Text("Dark mode") },
                    trailingContent = { Switch(checked = darkMode, onCheckedChange = { darkMode = it }) }
                )
            }

            item { SectionHeader("Privacy & Security") }
            item { ListItem(headlineContent = { Text("Privacy") }, supportingContent = { Text("Who can discover and message this device") }) }
            item { ListItem(headlineContent = { Text("Security") }, supportingContent = { Text("Device identity & message authentication — see Phase 7") }) }
            item { ListItem(headlineContent = { Text("Permissions") }, supportingContent = { Text("Bluetooth, Wi-Fi and location — requested in Phase 3") }) }
            item { ListItem(headlineContent = { Text("Notifications") }, supportingContent = { Text("Alerts for new and emergency messages") }) }

            item { SectionHeader("Developer") }
            item {
                ListItem(
                    headlineContent = { Text("Demo mode") },
                    supportingContent = { Text("Shows clearly-labeled simulated peers/messages for UI testing") },
                    trailingContent = { Switch(checked = demoMode, onCheckedChange = { demoMode = it }) }
                )
            }

            item { SectionHeader("About") }
            item {
                ListItem(
                    headlineContent = { Text("About MeshLink") },
                    supportingContent = {
                        Text(
                            "v0.1.0 · Phase 1 (architecture + navigation). Offline mesh " +
                                "messaging over Bluetooth/Wi-Fi — no cloud service required for " +
                                "core messaging."
                        )
                    }
                )
            }
        }
    }
}

@Composable
private fun SectionHeader(title: String) {
    Text(
        title,
        style = MaterialTheme.typography.labelSmall,
        color = MaterialTheme.colorScheme.primary,
        modifier = Modifier.padding(start = 16.dp, top = 16.dp, bottom = 4.dp)
    )
}
