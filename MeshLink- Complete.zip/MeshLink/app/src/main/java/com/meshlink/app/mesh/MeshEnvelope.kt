package com.meshlink.app.mesh

import org.json.JSONObject

/**
 * The wire format sent as raw bytes over a Nearby Connections BYTES Payload.
 * This is the ONLY thing that crosses the radio between two MeshLink
 * phones — a small JSON object, no internet, no server involved.
 *
 * `type`:
 *   - "message" — a real chat/emergency message (see fields below)
 *   - "ack"     — a tiny receipt sent back by the receiver once it has
 *                 durably stored the message in its own Room database.
 *                 Only on receiving this does the ORIGINAL sender mark its
 *                 outgoing copy DELIVERED. Until then it's SENT (meaning
 *                 only "the bytes reached the peer's radio stack",
 *                 confirmed separately via PayloadTransferUpdate).
 *
 * hopCount/expiryTime exist now so Phase 5 (multi-hop relay) has a real
 * wire format to build on; Phase 3 already uses them for a first, minimal
 * relay of EMERGENCY broadcasts (see MeshRepositoryImpl.handleIncomingMessage).
 */
data class MeshEnvelope(
    val type: String,
    val messageId: String,
    val senderId: String = "",
    val receiverId: String = "",
    val content: String = "",
    val timestamp: Long = 0L,
    val priority: String = "NORMAL",
    val hopCount: Int = 0,
    val expiryTime: Long = 0L
) {
    fun toJson(): String = JSONObject().apply {
        put("type", type)
        put("messageId", messageId)
        put("senderId", senderId)
        put("receiverId", receiverId)
        put("content", content)
        put("timestamp", timestamp)
        put("priority", priority)
        put("hopCount", hopCount)
        put("expiryTime", expiryTime)
    }.toString()

    companion object {
        fun ack(messageId: String) = MeshEnvelope(type = "ack", messageId = messageId)

        /** Returns null on malformed/foreign bytes rather than throwing — never trust the radio. */
        fun fromJson(raw: String): MeshEnvelope? = try {
            val o = JSONObject(raw)
            MeshEnvelope(
                type = o.optString("type", "message"),
                messageId = o.getString("messageId"),
                senderId = o.optString("senderId", ""),
                receiverId = o.optString("receiverId", ""),
                content = o.optString("content", ""),
                timestamp = o.optLong("timestamp", 0L),
                priority = o.optString("priority", "NORMAL"),
                hopCount = o.optInt("hopCount", 0),
                expiryTime = o.optLong("expiryTime", 0L)
            )
        } catch (e: Exception) {
            null
        }
    }
}
