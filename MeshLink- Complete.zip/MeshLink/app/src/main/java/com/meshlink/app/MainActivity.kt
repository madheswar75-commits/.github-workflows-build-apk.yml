package com.meshlink.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Surface
import androidx.compose.ui.Modifier
import com.meshlink.app.navigation.MeshLinkNavGraph
import com.meshlink.app.ui.theme.MeshLinkTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            MeshLinkTheme {
                Surface(modifier = Modifier.fillMaxSize()) {
                    MeshLinkNavGraph()
                }
            }
        }
    }
}
