package com.meshlink.app.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import com.meshlink.app.data.MeshStatus
import com.meshlink.app.data.MessageStatus
import com.meshlink.app.data.PeerConnectionState
import com.meshlink.app.ui.theme.MeshAmberSignal
import com.meshlink.app.ui.theme.MeshGreenSignal
import com.meshlink.app.ui.theme.MeshRedEmergency

@Composable
fun StatusChip(text: String, color: Color, modifier: Modifier = Modifier) {
    Box(
        modifier = modifier
            .background(color.copy(alpha = 0.15f), RoundedCornerShape(50))
            .padding(horizontal = 10.dp, vertical = 4.dp)
    ) {
        Text(text = text, style = MaterialTheme.typography.labelSmall, color = color)
    }
}

fun colorForPeerState(state: PeerConnectionState): Color = when (state) {
    PeerConnectionState.CONNECTED -> MeshGreenSignal
    PeerConnectionState.CONNECTING -> MeshAmberSignal
    PeerConnectionState.AVAILABLE -> Color.Gray
    PeerConnectionState.DISCONNECTED -> MeshRedEmergency
}

fun labelForPeerState(state: PeerConnectionState): String = when (state) {
    PeerConnectionState.CONNECTED -> "Connected"
    PeerConnectionState.CONNECTING -> "Connecting…"
    PeerConnectionState.AVAILABLE -> "Available"
    PeerConnectionState.DISCONNECTED -> "Disconnected"
}

fun colorForMessageStatus(status: MessageStatus): Color = when (status) {
    MessageStatus.DELIVERED -> MeshGreenSignal
    MessageStatus.SENT, MessageStatus.RELAYED -> MeshAmberSignal
    MessageStatus.QUEUED -> Color.Gray
    MessageStatus.FAILED -> MeshRedEmergency
}

fun labelForMeshStatus(status: MeshStatus): String = when (status) {
    MeshStatus.CONNECTED -> "CONNECTED"
    MeshStatus.SCANNING -> "SCANNING"
    MeshStatus.OFFLINE -> "OFFLINE"
}

fun colorForMeshStatus(status: MeshStatus): Color = when (status) {
    MeshStatus.CONNECTED -> MeshGreenSignal
    MeshStatus.SCANNING -> MeshAmberSignal
    MeshStatus.OFFLINE -> MeshRedEmergency
}
